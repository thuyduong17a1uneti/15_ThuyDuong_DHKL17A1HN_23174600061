import numpy as np

print("Numpy version:", np.__version__)
